/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.lang.enums;

public enum RoundingMode {
	CEIL, FLOOR, ROUND, TRUNC, ABS, OPPOSITE, UNNECESSARY;
}