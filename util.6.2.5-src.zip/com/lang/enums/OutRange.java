/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.lang.enums;

public enum OutRange {
	ASNULL, ASZERO, NORMAL;
}