/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.db.enums;

public enum DatabaseType {
	SQLServer, Oracle, MySQL, DB2, Sybase, PostgreSQL;
}